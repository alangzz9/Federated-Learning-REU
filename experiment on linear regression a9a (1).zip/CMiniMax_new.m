function [Oracle_outer,return_AUC_outer, return_AUC1_outer,Oracle_inner,return_AUC_inner, return_AUC1_inner] = ...
    CMiniMax_new ( stepsize_x,stepsize_y, PW, x_temp, alpha_temp, iter_num, n,nodes_num, ...
    gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0, features, labels, bs, minibatch,x_test,y_test, R, Pt)


Oracle_outer = zeros(iter_num+1,1);
return_AUC_outer = zeros(iter_num+1,1);
return_AUC1_outer = zeros(iter_num+1,1);
Oracle_outer(1,1) = 0;

Oracle_inner = zeros(iter_num*R+1,1);
return_AUC_inner = zeros(iter_num*R+1,1);
return_AUC1_inner = zeros(iter_num*R+1,1);
Oracle_inner(1,1) = 0;

N=nodes_num;

nT=ones(1,N);
p0=zeros(1,N);
p=zeros(1,N);

x_list = zeros(n+2, N, R);
y_list = zeros(1, N, R);


eta = stepsize_x;
eta_y = stepsize_y;
g = zeros(n+2, N);
h = zeros(1, N);


for iter  = 1 : iter_num %outer loop start
    shuffle_list = randperm(bs);
    if iter == 1
        x = reshape(x_temp(:,1),[n, N]);
        a = randn(1,N);
        b = randn(1,N);
        
        x_large = [x;a;b];
        y = reshape(alpha_temp(:,1),[1, N]);
    else
%         r_selected = randi(R,1);
        r_selected = R;
        x_temp = mean(x_list(:, :, r_selected), 2);
        x_large = zeros(n+2, N);
        for ii = 1:N
            x_large(:, ii) = x_temp;
        end

        y_temp = mean(y_list(:, :, r_selected), 2);
        y = zeros(1, N);
        for ii = 1:N
            y(:, ii) = y_temp;
        end
    end
    
    if iter == 1 
        x_cal = mean(x_large(1:n,:),2);% the mean weight of network
        y_pred_train=features'*x_cal;
        y_pred = x_test'*x_cal;
        [X,Y,T,AUC1] = perfcurve(labels,y_pred_train,1);
        [X,Y,T,AUC] = perfcurve(y_test,y_pred,1);
        
        return_AUC1_outer(1,1)=AUC1;
        return_AUC_outer(1,1)=AUC;
        return_AUC1_inner(1,1)=AUC1;
        return_AUC_inner(1,1)=AUC;
    end

    for rr = 1:R %inner loop start

        x_list(:, :, rr) = x_large;
        y_list(:, :, rr) = y;

        grad_v_temp = zeros(n+2,N);
        grad_v_old_temp = zeros(n+2,N);
        grad_alpha_temp = zeros(1,N);
        grad_alpha_old_temp = zeros(1,N);
        
        grad_v = zeros(n+2,N);
        grad_v_old = zeros(n+2,N);
        
        grad_alpha = zeros(1,N);
        grad_alpha_old = zeros(1,N);

        if rr == 1 | rand < Pt % if inner == 1 or p


            
            Oracle_inner((iter-1)*R + rr + 1, 1) = Oracle_inner((iter-1)*R + rr, 1) + bs;
            if rr == 1
                Oracle_outer(iter+1, 1) = Oracle_outer(iter, 1) + bs;
            else
                Oracle_outer(iter+1, 1) = Oracle_outer(iter+1, 1) + bs;
            end

            for ii = 1 : N
                jj=(ii-1)*bs+1:ii*bs;
    
                cur_label = labels(jj);
                % size(cur_label)
                pos = find(cur_label==1);
                
                pp = length(pos) / length(cur_label);
            
                for jj=(ii-1)*bs+1:ii*bs
                
                    if labels(jj)==1
                        gcx_1 = gc_v_1(x_large(:,ii),features(:,jj),[-1;0],[0;0], y(:,ii),pp);
                        gcy_1 = gc_alpha_1(x_large(:,ii),features(:,jj),[0;0], y(:,ii),pp);
    
                        grad_v_temp(:,ii) = grad_v_temp(:,ii) + gcx_1;
                        grad_alpha_temp(:,ii) = grad_alpha_temp(:,ii) +gcy_1;
                    else
    
                        gcx_0 = gc_v_0(x_large(:,ii),features(:,jj),[0;-1],[0;0], y(:,ii),pp);
                        gcy_0 = gc_alpha_0(x_large(:,ii),features(:,jj),[0;0], y(:,ii),pp);
    
                        
                        grad_v_temp(:,ii) = grad_v_temp(:,ii)+gcx_0;
                        grad_alpha_temp(:,ii) = grad_alpha_temp(:,ii)+gcy_0;
    
                    end
                end   

                grad_v(:,ii) = grad_v_temp(:,ii)/bs;
                grad_alpha(:,ii) = grad_alpha_temp(:,ii)/bs;

            end
            g_old = g;
            h_old = h;
            g = grad_v;
            h = grad_alpha;

        else % if inner != 1 and  1-p
            sample0 = shuffle_list((rr-1)*minibatch+1: min(rr*minibatch, bs));
            size(sample0)
            
            Oracle_outer(iter+1, 1) = Oracle_outer(iter+1, 1) + length(sample0);
            Oracle_inner((iter-1)*R + rr + 1, 1) = Oracle_inner((iter-1)*R + rr, 1) + length(sample0);

            for ii = 1 : N
                sample= sample0 + (ii-1)*bs;
                for i=1:size(sample,2)
    
                    jj = sample(i);
    
                    if labels(sample(i))==1
    
                        p(1,ii) = (p0(1,ii)*(nT(1,ii)-1)+1)/nT(1,ii);
    
                        gcx_1 = gc_v_1(x_large(:,ii),features(:,jj),[-1;0],[0;0], y(:,ii),p(1,ii));
                        gcy_1 = gc_alpha_1(x_large(:,ii),features(:,jj),[0;0], y(:,ii),p(1,ii));
    
                        gcx_1_old = gc_v_1(x_large_old(:,ii),features(:,jj),[-1;0],[0;0], y_old(:,ii),p(1,ii));
                        gcy_1_old = gc_alpha_1(x_large_old(:,ii),features(:,jj),[0;0], y_old(:,ii),p(1,ii));
    
                        grad_v_temp(:,ii) = grad_v_temp(:,ii) + gcx_1;
                        grad_v_old_temp(:,ii) = grad_v_old_temp(:,ii) + gcx_1_old;
    
                        grad_alpha_temp(:,ii) = grad_alpha_temp(:,ii) +gcy_1;
                        grad_alpha_old_temp(:,ii) = grad_alpha_old_temp(:,ii) + gcy_1_old;
    
                    else
    
                        p(1,ii) = (p0(1,ii)*(nT(1,ii)-1))/nT(1,ii);
                        gcx_0 = gc_v_0(x_large(:,ii),features(:,jj),[0;-1],[0;0], y(:,ii),p(1,ii));
                        gcy_0 = gc_alpha_0(x_large(:,ii),features(:,jj),[0;0], y(:,ii),p(1,ii));
    
                        gcx_0_old = gc_v_0(x_large_old(:,ii),features(:,jj),[0;-1],[0;0], y_old(:,ii),p(1,ii));
                        gcy_0_old = gc_alpha_0(x_large_old(:,ii),features(:,jj),[0;0], y_old(:,ii),p(1,ii));
    
                        grad_v_temp(:,ii) = grad_v_temp(:,ii)+gcx_0;
                        grad_v_old_temp(:,ii) = grad_v_old_temp(:,ii)+gcx_0_old;
                        grad_alpha_temp(:,ii) = grad_alpha_temp(:,ii)+gcy_0;
                        grad_alpha_old_temp(:,ii) = grad_alpha_old_temp(:,ii) + gcy_0_old;
    
                    end
                    nT(1,ii)=nT(1,ii)+1;
                    p0(1,ii)=p(1,ii);
                end   
    
                grad_v(:,ii) = grad_v_temp(:,ii)/minibatch;
                grad_alpha(:,ii) = grad_alpha_temp(:,ii)/minibatch;
                grad_v_old(:,ii) = grad_v_old_temp(:,ii)/minibatch;
                grad_alpha_old(:,ii) = grad_alpha_old_temp(:,ii)/minibatch;
    
            end
            
            g_old = g;
            h_old = h;
            g = g + grad_v - grad_v_old;
            h = h + grad_alpha   - grad_alpha_old;
        end
        
        if rr == 1
            v = g;
            u = h;
        else
            v = v * PW + g - g_old;
            u = u * PW + h - h_old;  
        end

        x_large_old = x_large;
        y_old = y;

        x_large = x_large * PW-eta*v ;
        y = y * PW + eta_y*u;
    
        x_cal = mean(x_large(1:n,:),2);% the mean weight of network
        y_pred_train=features'*x_cal;
        y_pred = x_test'*x_cal;
        [X,Y,T,AUC1] = perfcurve(labels,y_pred_train,1);
        [X,Y,T,AUC] = perfcurve(y_test,y_pred,1);

        if rr == R
            return_AUC1_outer(iter+1,1)=AUC1;
            return_AUC_outer(iter+1,1)=AUC;
            return_AUC1_inner((iter-1)*R + rr + 1,1)=AUC1;
            return_AUC_inner((iter-1)*R + rr + 1,1)=AUC;
        else
            return_AUC1_inner((iter-1)*R + rr + 1,1)=AUC1;
            return_AUC_inner((iter-1)*R + rr + 1,1)=AUC;
        end

    end
    disp(iter)




end

%disp(return_AUC)
%disp(return_AUC1)
%disp(Oracle)






















