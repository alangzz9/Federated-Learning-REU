function [Oracle, dist, gnorm, time] = BMiniMax_for_synthetic( stepsize_x,stepsize_y, PW, x_temp, alpha_temp, iter_num, n,nodes_num, bs, minibatch, A, B, C, e, f)

% output matrix
Oracle = zeros(iter_num-1,1);

dist = zeros(iter_num-1,1);
gnorm = zeros(iter_num-1,1); 
time = zeros(iter_num-1,1); 

N=nodes_num;
beta_x =0.01;
beta_y = 0.01;

x_large = reshape(x_temp,[n, N]);

x_large_old = x_large;

y = reshape(alpha_temp,[n, N]);
y_old = y;

%
v = zeros(n,N);
u = zeros(n,N);


g = zeros(n,N);
h = zeros(n,N);
g_old = zeros(n,N);
h_old = zeros(n,N);


%---- when iter=1; v=grad; u=grad;




grad_v=zeros(n,N);
grad_v_old=zeros(n,N);
grad_alpha=zeros(n,N);
grad_alpha_old=zeros(n,N);


grad_v_temp=zeros(n,N);
grad_alpha_temp=zeros(n,N);
initial_batch = minibatch;
sample0 = randi(bs,1,initial_batch);
Oracle(1, 1) = initial_batch;

for ii = 1 : N  
    sample=sample0+(ii-1)*bs;
    for i=1:size(sample,2)
        jj=sample(i);
        a_i = A(:,jj);
        c_i = C(:,jj);

        gcx_1 = (a_i * (a_i' * x_large(:,ii)) + c_i * (c_i' * y(:,ii)))  + e;
        grad_v_temp(:,ii) = grad_v_temp(:,ii) + gcx_1;

        b_i = B(:,jj);
        c_i =  C(:,jj);
        gcy_1 = (-b_i * (b_i' * y(:,ii)) + c_i * (c_i' * x_large(:,ii))) +  f;
        grad_alpha_temp(:,ii) = grad_alpha_temp(:,ii) +gcy_1;
    end   

    grad_v(:,ii) = grad_v_temp(:,ii)/initial_batch;
    grad_alpha(:,ii) = grad_alpha_temp(:,ii)/initial_batch;

end

g = grad_v;
h = grad_alpha;


%========
    eta = stepsize_x;%0.01;   %learning rate
    eta_y = stepsize_y;
%     beta_x =0.01;
%     beta_y = 0.01;
    
for iter  = 2 : iter_num  
    %%%%%%%%start the algorithm
    
    x_large_old = x_large;
    y_old = y;
    
    v = (v + g - g_old) * PW;
    u = (u + h - h_old) * PW;
    
    x_large = (x_large-eta*v) * PW;
    y = (y + eta_y*u) * PW;
   

  
    

    %calculate the auc
    x_cal = mean(x_large,2);
    y_cal = mean(y,2);
    cost = norm([x_cal, y_cal]);
    dist(iter-1,1)=cost;

    a_i = A(:,1:round(bs * nodes_num));
    c_i = C(:,1:round(bs * nodes_num));
    gx = (a_i * (a_i' * x_cal) + c_i * (c_i' * y_cal))/round(bs * nodes_num)  + e;
    b_i = B(:,1:round(bs * nodes_num));
    c_i =  C(:,1:round(bs * nodes_num));
    gy = (-b_i * (b_i' * y_cal) + c_i * (c_i' * x_cal))/round(bs * nodes_num) +  f;

    gnorm(iter-1,1) = norm([gx; gy],'fro');

    
    sample0 = randi(bs,1,minibatch);
    Oracle(iter, 1) = Oracle(iter-1, 1) + minibatch;
    
    

    
    
    grad_v_temp = zeros(n,N);
    grad_v_old_temp = zeros(n,N);
    grad_alpha_temp = zeros(n,N);
    grad_alpha_old_temp = zeros(n,N);
    
    grad_v = zeros(n,N);
    grad_v_old = zeros(n,N);
    
    grad_alpha = zeros(n,N);
    grad_alpha_old = zeros(n,N);
    

        
    for ii = 1 : N
    sample= sample0 + (ii-1)*bs;

        for i=1:size(sample,2)
            
            jj = sample(i);
            
            a_i =  A(:,jj);
            c_i =  C(:,jj);
            gcx_0 = (a_i * (a_i' * x_large(:,ii)) + c_i * (c_i' * y(:,ii)))  +  e;
            grad_v_temp(:,ii) = grad_v_temp(:,ii) + gcx_0;
            gcx_0_old = (a_i * (a_i' * x_large_old(:,ii)) + c_i * (c_i' * y_old(:,ii)))  +  e;
            grad_v_old_temp(:,ii) = grad_v_old_temp(:,ii) + gcx_0_old;                    

            b_i =  B(:,jj);
            c_i =  C(:,jj);
            gcy_0 = (-b_i * (b_i' * y(:,ii)) + c_i * (c_i' * x_large(:,ii))) +  f;
            grad_alpha_temp(:,ii) = grad_alpha_temp(:,ii) +gcy_0;
            gcy_0_old = (-b_i * (b_i' * y_old(:,ii)) + c_i * (c_i' * x_large_old(:,ii))) +  f;
            grad_alpha_old_temp(:,ii) = grad_alpha_old_temp(:,ii) +gcy_0_old;
        end   

        grad_v(:,ii) = grad_v_temp(:,ii)/minibatch;
        grad_alpha(:,ii) = grad_alpha_temp(:,ii)/minibatch;
        grad_v_old(:,ii) = grad_v_old_temp(:,ii)/minibatch;
        grad_alpha_old(:,ii) = grad_alpha_old_temp(:,ii)/minibatch;

        
    end
    
    g_old = g;
    h_old = h;
    g = grad_v + (1-beta_x)*(g - grad_v_old);
    h = grad_alpha + (1-beta_y)*(h - grad_alpha_old);

    
    disp(iter)
    


    x_cal = mean(x_large,2);% the mean weight of network
    y_cal = mean(y,2);
    cost = norm([x_cal, y_cal]);
    dist(iter-1,1)=cost;

    a_i = A(:,1:round(bs * nodes_num));
    c_i = C(:,1:round(bs * nodes_num));
    gx = (a_i * (a_i' * x_cal) + c_i * (c_i' * y_cal))/round(bs * nodes_num)  + e;
    b_i = B(:,1:round(bs * nodes_num));
    c_i =  C(:,1:round(bs * nodes_num));
    gy = (-b_i * (b_i' * y_cal) + c_i * (c_i' * x_cal))/round(bs * nodes_num) +  f;

    gnorm(iter-1,1) = norm([gx; gy],'fro');
end

