% "AUCtest_D",'AUCtrain_D'
clear
file_name = 'synthetic';
%Pt = 0.1;
Pt=sqrt(600)/(600 + sqrt(600));
lm_oc= 1000;
lm_od= 1000;
lm_i= 1000;

filename = append('random_result_',file_name,'_',num2str(Pt),'_.mat');
load(filename)
%filename_local = append('result_l2_',file_name,'_',num2str(Pt),'_.mat');
% load(filename_local)


% semilogy(dist_B_raw(1:99),'LineWidth', 3);
% hold on;
% semilogy(dist_C(2:lm_oc),'LineWidth', 3);
% hold on;
% semilogy(dist_D(1:lm_od),'LineWidth',3);
% hold on;
% semilogy(dist_C_local(2:lm_oc),'LineWidth',3);
% hold on;
% semilogy(dist_D_local(2:lm_od),'LineWidth',3);


% semilogy(Oracle_B_raw(1:5000-1), dist_B_raw(1:5000-1),'LineWidth', 3);
% hold on;
% semilogy(Oracle_C_raw(1:5000-1), dist_C_raw(1:5000-1),'LineWidth', 3);
% hold on;
% semilogy(Oracle_C(2:lm_oc), dist_C(2:lm_oc),'LineWidth', 3);
% hold on;
% semilogy(Oracle_D(2:lm_od), dist_D(2:lm_od),'LineWidth',3);
% hold on;

% semilogy(Oracle_B_raw(1:5000-1),gnorm_B_raw(1:5000-1),'LineWidth', 3);
% hold on;
% semilogy(Oracle_C_raw(1:5000-1),gnorm_C_raw(1:5000-1),'LineWidth', 3);
% hold on;
% semilogy(Oracle_C(2:lm_oc),gnorm_C(2:lm_oc),'LineWidth', 3);
% hold on;
% semilogy(Oracle_D(2:lm_oc),gnorm_D(2:lm_od),'LineWidth',3);
% hold on;



% semilogy(Oracle_C_local(2:lm_oc), dist_C_local(2:lm_oc),'LineWidth',3);
% hold on;
% semilogy(Oracle_D_local(2:lm_od), dist_D_local(2:lm_od),'LineWidth',3);

% semilogy(time_C(2:lm_oc), gnorm_C(2:lm_oc),'LineWidth', 3);
% hold on;
% semilogy(time_D(2:lm_od), gnorm_D(2:lm_od),'LineWidth',3);
% hold on;
% semilogy(time_C_local(2:lm_oc), gnorm_C_local(2:lm_oc),'LineWidth',3);
% hold on;
% semilogy(time_D_local(2:lm_od), gnorm_D_local(2:lm_od),'LineWidth',3);

semilogy(dist_B_raw,'LineWidth', 3);
hold on;
semilogy(dist_C_raw,'LineWidth', 3);
hold on;
semilogy(dist_C_i,'LineWidth', 3);
hold on;
semilogy(dist_D_i,'LineWidth',3);
hold on;


legend('B\_raw','C\_raw','DSVRGDA\_P','DSVRGDA\_Z','SVRGDA\_P', 'SVRGDA\_Z', 'FontSize',13, 'location', 'southeast');
xlabel('sample complexity', 'FontSize', 15)
% xlabel('iteration', 'FontSize', 15)
% str = '$$\Vert \bar x - x^{\ast} \Vert^2 + \Vert \bar y - y^{\ast} \Vert^2 $$';
str = '$$\Vert \nabla f(\bar x,\bar y) \Vert^2  $$';
ylabel(str,'Interpreter','latex','FontSize',15);
ylim([1e-11,1]);
set(gca,'FontSize',13);