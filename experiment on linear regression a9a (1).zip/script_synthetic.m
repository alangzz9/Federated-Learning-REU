%clc; clear; close all;
clc;
clear
close all
tic
rng('default')




file_name = 'synthetic';
prob = 'line_log';



% % Parameters
n =          10;   % problem dimention
nodes_num  = 10;    % number of agents in the network
epoch_num  = 1000;
fig = 1;

generate_graph(nodes_num, 0.5, n, fig);
graph = load('graph_10.mat');
PW = graph.weights;


n_1 = 6000;
d = 10;
r = 5;
cond = 1e5;
data = pl_data_generator(n_1, d, cond,r);




% % Algorithms
x_initial = randn(nodes_num*n,epoch_num);
x_initial(:,1) = 1*randn(nodes_num*n,1);
alpha_initial = randn(nodes_num*1,epoch_num);
alpha_initial(:,1) = 1*randn(nodes_num,1);


 
iter_num = 100;
batch_size = round(n_1/nodes_num);
%Pt = 0.1;
Pt=sqrt(batch_size)/(batch_size + sqrt(batch_size));
stepsize_x=0.01;
stepsize_y=0.01;
minibatch_D=round(sqrt(batch_size));
minibatch_C=round(sqrt(batch_size));
minibatch_local = round(sqrt(batch_size));
rho = sqrt(0.5/batch_size);
R = round(sqrt(batch_size));

if fig == 1
    filename = append('random_result_',file_name,'_',num2str(Pt),'_.mat');
else
    filename = append('result_',file_name,'_',num2str(Pt),'_.mat');
end

time = 0;
if time == 1
    filename = append('time_result_',file_name,'_',num2str(Pt),'_.mat');
    
end

disp('C start')
% iter_num = 100;
[Oracle_C, dist_C, gnorm_C, time_C] = CMiniMax_new_for_synthetic(stepsize_x, stepsize_y, PW, data.w_init, data.z_init, iter_num, n,nodes_num,batch_size, minibatch_C,R, Pt, data.A, data.B, data.C, data.e, data.f);
save(filename, "Oracle_C","dist_C",'gnorm_C',"time_C",'-append')


% "AUCtest_D",'AUCtrain_D'
clear
file_name = 'synthetic';
%Pt = 0.1;
Pt=sqrt(600)/(600 + sqrt(600));
lm_oc= 100;
lm_od= 100;
lm_i= 1000;

filename = append('random_result_',file_name,'_',num2str(Pt),'_.mat');
load(filename)
%filename_local = append('result_l2_',file_name,'_',num2str(Pt),'_.mat');
% load(filename_local)



semilogy(Oracle_C(1:lm_oc), dist_C(1:lm_oc),'LineWidth', 3);


% semilogy(time_C(2:lm_oc), gnorm_C(2:lm_oc),'LineWidth', 3);
% hold on;
% semilogy(time_D(2:lm_od), gnorm_D(2:lm_od),'LineWidth',3);
% hold on;
% semilogy(time_C_local(2:lm_oc), gnorm_C_local(2:lm_oc),'LineWidth',3);
% hold on;
% semilogy(time_D_local(2:lm_od), gnorm_D_local(2:lm_od),'LineWidth',3);
Oracle_C
dist_C

legend('DSVRGDA\_P','DSVRGDA\_Z','SVRGDA\_P', 'SVRGDA\_Z', 'FontSize',13, 'location', 'southeast');
xlabel('sample complexity', 'FontSize', 15)
str = '$$\Vert \bar x - x^{\ast} \Vert^2 + \Vert \bar y - y^{\ast} \Vert^2 $$';
%str = '$$\Vert \nabla f(\bar x,\bar y) \Vert^2  $$';
ylabel(str,'Interpreter','latex','FontSize',15);
ylim([1e-11,1]);
set(gca,'FontSize',13);

            