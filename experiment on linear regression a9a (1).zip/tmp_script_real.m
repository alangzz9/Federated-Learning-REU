%clc; clear; close all;
clc;
clear
close all
tic
rng('default')

file_list = ["a9a", 'ijcnn1','w8a'];
n_list = [123, 22, 300];

% for ii = 1 : 3

% file_name = file_list(ii);
file_name = file_list(1);
prob = 'line_log';

fc_1 = @(x,feature,ab1,ab0,alpha,p)  (((1-p)*(x'*[feature;ab1]).^2-2*(1+alpha)*(1-p)*x'*[feature;ab0])-p*(1-p)*alpha^2) + 0.001 * sum(x.^2 ./ (1+x.^2));
fc_0 = @(x,feature,ab1,ab0,alpha,p)  (p*(x'*[feature;ab1]).^2+ 2*(1+alpha)*p*x'*[feature;ab0]-p*(1-p)*alpha^2) + 0.001 * sum(x.^2 ./ (1+x.^2));

gc_v_1 = @(x,feature,ab1,ab0,alpha,p) 2*(1-p)*[feature;ab1]'*[feature;ab1]*x - 2*(1+alpha)*(1-p)*[feature;ab0]+2*0.001*x ./ (1+x.^2).^2;
gc_v_0 = @(x,feature,ab1,ab0,alpha,p) 2*p*([feature;ab1])'*[feature;ab1]*x+2*(1+alpha)*p*[feature;ab0]+2*0.001*x ./ (1+x.^2).^2;

gc_alpha_1 = @(x,feature,ab0,alpha,p) -2*(1-p)*x'*[feature;ab0] - 2*p*(1-p)*alpha;
gc_alpha_0 = @(x,feature,ab0,alpha,p) 2*p*x'*[feature;ab0]- 2*p*(1-p)*alpha;


% % Parameters
% n =          n_list(ii);   % problem dimention
n =          n_list(1);
nodes_num  = 10;    % number of agents in the network
epoch_num  = 1000;


fig = 1;
generate_graph(nodes_num, 0.5, n, fig);
graph = load('graph_10.mat');
Adj = graph.Adj;
PW = graph.weights;
A = graph.edges;



% load data; split features and labels
load(sprintf('./data/%s.mat', file_name))
features = full(features);
labels = labels';
labels = cast(labels,'double');
labels(labels==0) = -1;
labels(labels==2) = -1;
for idx = 1: size(labels, 1)
    features(idx, :) =  features(idx, :)./(norm(features(idx,:))+eps);
end

%%%% split the data
split_size=0.2;

index1 = find(labels==1);
index0 = find(labels==-1);

less= min(length(index1),length(index0));
label1 = index1(randperm(numel(index1),round(split_size/2*less)));
label0 = index0(randperm(numel(index0),round(split_size/2*less)));

x_test = features([label1,label0],:);
y_test = labels([label1,label0],:);
rand_index = randperm(size(y_test,1));
x_test = x_test(rand_index,:)';
y_test = y_test(rand_index,:);

x_train = features;
x_train([label1,label0],:)=[];
y_train = labels;
y_train([label1,label0],:)=[];


batch_size = floor(size(y_train,1)/nodes_num);
K = batch_size * nodes_num;


rand_index = randperm(size(y_train,1));
x_train = x_train(rand_index, :);
y_train = y_train(rand_index,:);
x_train = x_train(1:K,:)';
y_train = y_train(1:K,:);


% % Algorithms
x_initial = zeros(nodes_num*n,epoch_num);
x_initial(:,1) = 1*randn(nodes_num*n,1);
alpha_initial = zeros(nodes_num*1,epoch_num);
alpha_initial(:,1) = 1*randn(nodes_num,1);
batch_size_ = floor(size(y_train,1)/nodes_num)*nodes_num;
x_initial_ = zeros(n,epoch_num);
x_initial_(:,1) = 1*rand(n,1);
alpha_initial_ = zeros(1,epoch_num);
alpha_initial_(:,1) = 1*randn(1,1);
 
iter_num = 1000;
%Pt = 0.1;
Pt=sqrt(batch_size)/(batch_size + sqrt(batch_size));
stepsize_x=0.1;
stepsize_y=0.1;
minibatch_D=round(sqrt(batch_size));
minibatch_C=round(sqrt(batch_size));
minibatch_local = round(sqrt(batch_size));
rho = sqrt(0.5/batch_size);
R = round(sqrt(batch_size));
if fig == 1
    filename = append('random_result_',file_name,'_',num2str(Pt),'_.mat');
    filename_l2 = append('random_result_l2_',file_name,'_',num2str(Pt),'_.mat');
else
    filename = append('result_',file_name,'_',num2str(Pt),'_.mat');
    filename_l2 = append('result_l2_',file_name,'_',num2str(Pt),'_.mat');
end

iter_num = 2000;         
disp('C_raw start')
[Obj_C_raw, Oracle_C_raw,return_AUC_C_raw] = CMiniMax_real(stepsize_x, stepsize_y, PW, x_initial, alpha_initial, iter_num, n,nodes_num,gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0, x_train,y_train, batch_size, minibatch_C,x_test,y_test);
save(filename, 'Obj_C_raw', 'Oracle_C_raw','return_AUC_C_raw' )

iter_num = 2000;
disp('B_raw start')
beta_x = 0.01;
beta_y = 0.01;
stepsize_x=0.01;
stepsize_y=0.01;
[Obj_B_raw, Oracle_B_raw,return_AUC_B_raw] = BMiniMax_real(stepsize_x, stepsize_y, PW, x_initial, alpha_initial, iter_num, n,nodes_num,gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0, x_train,y_train, batch_size, minibatch_C,x_test,y_test,beta_x,beta_y);
save(filename, 'Obj_B_raw', 'Oracle_B_raw','return_AUC_B_raw','-append' )% 

stepsize_x=0.1;
stepsize_y=0.1;
iter_num = 80;
disp('D start')
[Oracle_D_o, AUCtest_D_o, AUCtrain_D_o, Oracle_D_i, AUCtest_D_i, AUCtrain_D_i] = DMiniMax_new(stepsize_x, stepsize_y, PW, x_initial, alpha_initial, iter_num, n,nodes_num,gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0,x_train,y_train, batch_size, minibatch_D,x_test,y_test,rho,R);
save(filename, "Oracle_D_o","AUCtest_D_o",'AUCtrain_D_o',"Oracle_D_i","AUCtest_D_i",'AUCtrain_D_i', '-append')

disp('C start')
[Oracle_C_o,AUCtest_C_o,AUCtrain_C_o,Oracle_C_i,AUCtest_C_i,AUCtrain_C_i] = CMiniMax_new(stepsize_x, stepsize_y, PW, x_initial, alpha_initial, iter_num, n,nodes_num,gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0, x_train,y_train, batch_size, minibatch_C,x_test,y_test, R, Pt);
save(filename,  "Oracle_C_o","AUCtest_C_o",'AUCtrain_C_o',"Oracle_C_i","AUCtest_C_i",'AUCtrain_C_i', '-append')


% end