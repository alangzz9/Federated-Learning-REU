% "AUCtest_D",'AUCtrain_D'
clear
file_name = 'covtype';
%Pt = 0.1;
%"a9a", 'ijcnn1','w8a','covtype'
%3099, 4902, 4945,52435
batch_size = 52435;
Pt=sqrt(batch_size)/(batch_size + sqrt(batch_size));
lm_oc= 90;
lm_od= 120;
lm_i= 2000;

filename = append('random_result_',file_name,'_',num2str(Pt),'_.mat');
load(filename)
%filename_local = append('result_l2_',file_name,'_',num2str(Pt),'_.mat');
% load(filename_local)


plot(Oracle_C_o(1:lm_oc), AUCtest_C_o(1:lm_oc),'LineWidth', 3);
hold on;
plot(Oracle_D_o(1:lm_od), AUCtest_D_o(1:lm_od),'LineWidth',3);
hold on;
plot(Oracle_C_o_local(1:lm_oc), AUCtest_C_o_local(1:lm_oc),'LineWidth',3);
hold on;
plot(Oracle_D_o_local(1:lm_od), AUCtest_D_o_local(1:lm_od),'LineWidth',3);



legend('DSVRGDA\_P','DSVRGDA\_Z','SVRGDA\_P', 'SVRGDA\_Z', 'FontSize',13, 'location', 'southeast');
xlabel('sample complexity', 'FontSize', 15)
ylabel('AUC test','FontSize',15)
set(gca,'FontSize',13);
%ylim([0.45,0.9])
