function [Opt_grad, Opt_concensus, Obj, Oracle,return_AUC,return_accuracy,return_AUC1] = LMiniMax ( stepsize_x,stepsize_y, PW, x_temp, alpha_temp, iter_num, A, n,nodes_num,gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0,fc_1,fc_0,function_lambda,function_aalpha, features, labels, bs, minibatch,x_test,y_test,rho)

% output matrix
Opt_grad = zeros(iter_num-1,1);      %gradient norm
Opt_concensus = zeros(iter_num-1,1); % it's evaluation of the network and nodes
Constraint = zeros(iter_num-1,1);
Obj = zeros(iter_num-1,1);           %loss function
Oracle = zeros(iter_num-1,1);  %communication time


return_AUC = zeros(iter_num-1,1);
return_AUC1 = zeros(iter_num-1,1);
return_accuracy = zeros(iter_num-1,1);
N=nodes_num;
%
x = reshape(x_temp(:,1),[n,N]);
a = randn(1,N);
b = randn(1,N);

x_large = [x;a;b];
x_large_old = x_large;

y = reshape(alpha_temp(:,1),[1, N]);
y_old = y;


%
v = zeros(n+2,N);
v_old=zeros(n+2,N);
aa = zeros(n+2,N);
u = zeros(1,N);
u_old = zeros(1,N);
bb= zeros(1,N);

g = zeros(n+2,bs,N);
h = zeros(1,bs,N);
g_sample_mean=zeros(n+2,N);
h_sample_mean=zeros(1,N);


%---- when iter=1; v=grad; u=grad;


Oracle(1, 1) =  minibatch;

grad_v=zeros(n+2,N);
grad_v_old=zeros(n+2,N);
grad_alpha=zeros(1,N);
grad_alpha_old=zeros(1,N);
nT=ones(1,N);
p0=zeros(1,N);
p=zeros(1,N);

grad_v_temp=zeros(n+2,N);
grad_alpha_temp=zeros(1,N);
sample0 = randi(bs,1,minibatch);
for ii = 1 : N  
        sample=sample0+(ii-1)*bs;
        for i=1:size(sample,2);
            jj=sample(i);
            if labels(sample(i))==1
                p(1,ii) = (p0(1,ii)*(nT(1,ii)-1)+1)/nT(1,ii);
                gcx_1 = gc_v_1(x_large(:,ii),features(:,jj),[-1;0],[0;0], y(:,ii),p(1,ii));%,length(gind1), N);
                gcy_1 = gc_alpha_1(x_large(:,ii),features(:,jj),[0;0], y(:,ii),p(1,ii));%,length(gind1), N);

                grad_v_temp(:,ii)=grad_v_temp(:,ii)+gcx_1;
                grad_alpha_temp(:,ii)=grad_alpha_temp(:,ii)+gcy_1;
            else
                p = (p0*(nT(1,ii)-1))/nT(1,ii);
                gcx_0 = gc_v_0(x_large(:,ii),features(:,jj),[0;-1],[0;0], y(:,ii),p(1,ii));%,length(gind0), N);
                gcy_0 = gc_alpha_0(x_large(:,ii),features(:,jj),[0;0], y(:,ii),p(1,ii));%,length(gind0), N);

                grad_v_temp(:,ii)=grad_v_temp(:,ii)+gcx_0;
                grad_alpha_temp(:,ii)=grad_alpha_temp(:,ii)+gcy_0;
            end

        nT(1,ii)=nT(1,ii)+1;
        p0(1,ii)=p(1,ii);
        end
        
        
        grad_v(:,ii) = grad_v_temp(:,ii)/minibatch;
        grad_alpha(:,ii) = grad_alpha_temp(:,ii)/minibatch;
end

v = grad_v;
u = grad_alpha;


%========
    eta = stepsize_x;%0.01;   %learning rate
    eta_y = stepsize_y;
    rho %1/(2*sqrt(bs));
    gamma_x=1;
    gamma_y=1;
    
for iter  = 2 : iter_num  
    %%%%%%%%start the algorithm
    


    x_large_old = x_large;
    %aa =  aa* PW + v - v_old;
    %x_med = x_large *PW - gamma_x * aa;
    x_large = x_large  - gamma_x* eta*v;
    y_old = y;
    %bb =  bb * PW + u - u_old;
    y = y  + gamma_y *eta_y* u;
    %y = y + eta* (y_med  - y);
  
    

    %calculate the auc
    
    x_cal = mean(x_large(1:n,:),2);
    y_pred_train=features'*x_cal;
    y_pred = x_test'*x_cal;
    y_label = sign(y_pred);
    [X,Y,T,AUC1] = perfcurve(labels,y_pred_train,1);
    
    [X,Y,T,AUC] = perfcurve(y_test,y_pred,1);
    
    return_AUC1(iter-1,1)=AUC1;
    correct=0;
    
    for i=1: length(y_pred)
        if y_label(i)==y_test(i)
            correct=correct+1;
        end
    end
    
    correct=correct/length(y_pred);
    
    return_AUC(iter-1,1)=AUC;
    
    return_accuracy(iter-1,1)=correct;

    
    sample0 = randi(bs,1,minibatch);
    
    Oracle(iter, 1) = Oracle(iter-1, 1) + minibatch;
    
    g_mean = mean(g,2);
    g_mean = reshape(g_mean,[n+2,N]);
    h_mean = mean(h,2);
    h_mean = reshape(h_mean,[1,N]);
    
    
    g_sample_mean = mean(g(:,sample0,:),2);
    g_sample_mean = reshape(g_sample_mean,[n+2,N]);
    
    h_sample_mean = mean(h(:,sample0,:),2);
    h_sample_mean = reshape(h_sample_mean,[1,N]);
    
    
    grad_v_temp = zeros(n+2,N);
    grad_v_old_temp = zeros(n+2,N);
    grad_alpha_temp = zeros(1,N);
    grad_alpha_old_temp = zeros(1,N);
    
    grad_v = zeros(n+2,N);
    grad_v_old = zeros(n+2,N);
    
    grad_alpha = zeros(1,N);
    grad_alpha_old = zeros(1,N);
        
    for ii = 1 : N
        
    sample= sample0 + (ii-1)*bs;
        for i=1:size(sample,2)
            
            jj = sample(i);
            
            if labels(sample(i))==1
                
            p(1,ii) = (p0(1,ii)*(nT(1,ii)-1)+1)/nT(1,ii);
            
            gcx_1 = gc_v_1(x_large(:,ii),features(:,jj),[-1;0],[0;0], y(:,ii),p(1,ii));
            gcy_1 = gc_alpha_1(x_large(:,ii),features(:,jj),[0;0], y(:,ii),p(1,ii));
            
            gcx_1_old = gc_v_1(x_large_old(:,ii),features(:,jj),[-1;0],[0;0], y(:,ii),p(1,ii));
            gcy_1_old = gc_alpha_1(x_large_old(:,ii),features(:,jj),[0;0], y(:,ii),p(1,ii));
            
            grad_v_temp(:,ii) = grad_v_temp(:,ii) + gcx_1;
            grad_v_old_temp(:,ii) = grad_v_old_temp(:,ii) + gcx_1_old;
            
            grad_alpha_temp(:,ii) = grad_alpha_temp(:,ii) +gcy_1;
            grad_alpha_old_temp(:,ii) = grad_alpha_old_temp(:,ii) + gcy_1_old;
            
            g(:,sample0(i),ii) = gcx_1;
            h(:,sample0(i),ii) = gcy_1;
           
            
            else
                
            p(1,ii) = (p0(1,ii)*(nT(1,ii)-1))/nT(1,ii);
            gcx_0 = gc_v_0(x_large(:,ii),features(:,jj),[0;-1],[0;0], y(:,ii),p(1,ii));
            gcy_0 = gc_alpha_0(x_large(:,ii),features(:,jj),[0;0], y(:,ii),p(1,ii));
          
            gcx_0_old = gc_v_0(x_large_old(:,ii),features(:,jj),[0;-1],[0;0], y(:,ii),p(1,ii));
            gcy_0_old = gc_alpha_0(x_large_old(:,ii),features(:,jj),[0;0], y(:,ii),p(1,ii));
            
            grad_v_temp(:,ii) = grad_v_temp(:,ii)+gcx_0;
            grad_v_old_temp(:,ii) = grad_v_old_temp(:,ii)+gcx_0_old;
            grad_alpha_temp(:,ii) = grad_alpha_temp(:,ii)+gcy_0;
            grad_alpha_old_temp(:,ii) = grad_alpha_old_temp(:,ii) + gcy_0_old;
            
            g(:,sample0(i),ii) = gcx_0;
            h(:,sample0(i),ii) = gcy_0;
            
            end
            nT(1,ii)=nT(1,ii)+1;
            p0(1,ii)=p(1,ii);
        end   
        
        grad_v(:,ii) = grad_v_temp(:,ii)/minibatch;
        grad_alpha(:,ii) = grad_alpha_temp(:,ii)/minibatch;
        grad_v_old(:,ii) = grad_v_old_temp(:,ii)/minibatch;
        grad_alpha_old(:,ii) = grad_alpha_old_temp(:,ii)/minibatch;
    end

    v_old = v;
    u_old = u;
    v = grad_v -grad_v_old + (1-rho)*v_old + rho* (grad_v_old - g_sample_mean + g_mean);
    u = grad_alpha -grad_alpha_old + (1-rho)*u_old + rho* (grad_alpha_old - h_sample_mean + h_mean);
end

