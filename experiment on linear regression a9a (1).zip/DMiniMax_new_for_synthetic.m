function [Oracle, dist, gnorm, time, dist_inner, gnorm_inner] = DMiniMax_new_for_synthetic ( stepsize_x, stepsize_y, PW, x_temp, alpha_temp, iter_num, n, nodes_num, bs, minibatch,rho, R, A, B, C, e, f)

Oracle = zeros(iter_num+1,1);
Oracle(1, 1) = 0;
dist = zeros(iter_num+1,1);
gnorm = zeros(iter_num+1,1); 
time = zeros(iter_num+1,1);
time(1,1) = 0;
gnorm_inner = zeros(iter_num*R+1,1);
dist_inner = zeros(iter_num*R+1,1);
N=nodes_num;

shuffle_list = randperm(bs);

for iter = 1:iter_num
    tic;

    if iter == 1
        x_large = reshape(x_temp,[n, N]);
        y = reshape(alpha_temp,[n, N]);
    else
%         r_selected = randi(R,1);
        r_selected = R;
        x_temp = mean(x_list(:, :, r_selected), 2);
        x_large = zeros(n, N);
        for ii = 1:N
            x_large(:, ii) = x_temp;
        end
        
        y_temp = mean(y_list(:, :, r_selected), 2);
        y = zeros(n, N);
        for ii = 1:N
            y(:, ii) = y_temp;
        end
    end
    g = zeros(n,bs,N);
    h = zeros(n,bs,N);

    eta = stepsize_x;
    eta_y = stepsize_y;    

    x_list = zeros(n, N, R);
    y_list = zeros(n, N, R);
    
    if iter == 1 
    x_cal = mean(x_large,2);% the mean weight of network
    y_cal = mean(y,2);
    cost = norm([x_cal, y_cal]);
    dist(1,1)=cost;
    dist_inner(1,1) = cost;
    a_i = A(:,1:round(bs * nodes_num));
    c_i = C(:,1:round(bs * nodes_num));
    gx = (a_i * (a_i' * x_cal) + c_i * (c_i' * y_cal))/round(bs * nodes_num)  + e;
    b_i = B(:,1:round(bs * nodes_num));
    c_i =  C(:,1:round(bs * nodes_num));
    gy = (-b_i * (b_i' * y_cal) + c_i * (c_i' * x_cal))/round(bs * nodes_num) +  f;

    gnorm(1,1) = norm([gx; gy],'fro');
    gnorm_inner(1,1) = norm([gx; gy],'fro');
    end
    for rr = 1 : R
        
        x_list(:, :, rr) = x_large;
        y_list(:, :, rr) = y;

        %sample0 = shuffle_list((rr-1)*minibatch+1: min(rr*minibatch, bs));
        sample0 = randi(bs,1,minibatch);

        


        g_mean = mean(g,2);%get the mean of all samples in bs
        g_mean = reshape(g_mean,[n,N]);
        h_mean = mean(h,2);
        h_mean = reshape(h_mean,[n,N]);
        
        
        g_sample_mean = mean(g(:,sample0,:),2);%get mean of selected samples
        g_sample_mean = reshape(g_sample_mean,[n,N]);
        
        h_sample_mean = mean(h(:,sample0,:),2);
        h_sample_mean = reshape(h_sample_mean,[n,N]);
        
        
        grad_v_temp = zeros(n,N);
        grad_v_old_temp = zeros(n,N);
        grad_alpha_temp = zeros(n,N);
        grad_alpha_old_temp = zeros(n,N);
        
        grad_v = zeros(n,N);
        grad_v_old = zeros(n,N);
        
        grad_alpha = zeros(n,N);
        grad_alpha_old = zeros(n,N);
        if rr == 1

            Oracle(iter+1, 1) = Oracle(iter, 1) + bs;


            for ii = 1 : N  

                for jj=(ii-1)*bs+1:ii*bs

                    a_i = A(:,jj);
                    c_i = C(:,jj);

                    gcx_1 = (a_i * (a_i' * x_large(:,ii)) + c_i * (c_i' * y(:,ii)))  + e;
                    grad_v_temp(:,ii) = grad_v_temp(:,ii) + gcx_1;

                    b_i = B(:,jj);
                    c_i =  C(:,jj);
                    gcy_1 = (-b_i * (b_i' * y(:,ii)) + c_i * (c_i' * x_large(:,ii))) +  f;
                    grad_alpha_temp(:,ii) = grad_alpha_temp(:,ii) +gcy_1;

                    g(:,jj-(ii-1)*bs,ii) = gcx_1;
                    h(:,jj-(ii-1)*bs,ii) = gcy_1;
                end
                
                
                grad_v(:,ii) = grad_v_temp(:,ii)/bs;
                grad_alpha(:,ii) = grad_alpha_temp(:,ii)/bs;
            end
            v = grad_v;
            u = grad_alpha;
        else

            Oracle(iter+1, 1) = Oracle(iter+1, 1) + length(sample0);

            for ii = 1 : N %how it achieved on distributed nodes?
                sample= sample0 + (ii-1)*bs;
                for i=1:size(sample,2)% go througn the mnbatch

                    jj = sample(i);

                    a_i =  A(:,jj);
                    c_i =  C(:,jj);
                    gcx_0 = (a_i * (a_i' * x_large(:,ii)) + c_i * (c_i' * y(:,ii)))  +  e;
                    grad_v_temp(:,ii) = grad_v_temp(:,ii) + gcx_0;
                    gcx_0_old = (a_i * (a_i' * x_large_old(:,ii)) + c_i * (c_i' * y_old(:,ii)))  +  e;
                    grad_v_old_temp(:,ii) = grad_v_old_temp(:,ii) + gcx_0_old;                    

                    b_i =  B(:,jj);
                    c_i =  C(:,jj);
                    gcy_0 = (-b_i * (b_i' * y(:,ii)) + c_i * (c_i' * x_large(:,ii))) +  f;
                    grad_alpha_temp(:,ii) = grad_alpha_temp(:,ii) +gcy_0;
                    gcy_0_old = (-b_i * (b_i' * y_old(:,ii)) + c_i * (c_i' * x_large_old(:,ii))) +  f;
                    grad_alpha_old_temp(:,ii) = grad_alpha_old_temp(:,ii) +gcy_0_old;

                    g(:,sample0(i),ii) = gcx_0;
                    h(:,sample0(i),ii) = gcy_0;

                end 
                grad_v(:,ii) = grad_v_temp(:,ii)/length(sample0);
                grad_alpha(:,ii) = grad_alpha_temp(:,ii)/length(sample0);
                grad_v_old(:,ii) = grad_v_old_temp(:,ii)/length(sample0);
                grad_alpha_old(:,ii) = grad_alpha_old_temp(:,ii)/length(sample0);
            end
            v_old = v;
            u_old = u;
            v = grad_v - grad_v_old + (1-rho)*v_old + rho* (grad_v_old - g_sample_mean + g_mean);
            u = grad_alpha -grad_alpha_old + (1-rho)*u_old + rho* (grad_alpha_old - h_sample_mean + h_mean);
        end


        if rr == 1
            aa = v;
            bb = u;
        else
            aa =  aa* PW + v - v_old;
            bb =  bb * PW + u - u_old;
        end
        x_large_old = x_large;
        x_large = x_large *PW  - eta*aa;
        
        y_old = y;
        y = y*PW + eta_y* bb;
        
        toc;
        time(iter+1) = time(iter) + toc;
        x_cal = mean(x_large,2);% the mean weight of network
        y_cal = mean(y,2);
        cost = norm([x_cal, y_cal]);
    
        a_i = A(:,1:round(bs * nodes_num));
        c_i = C(:,1:round(bs * nodes_num));
        gx = (a_i * (a_i' * x_cal) + c_i * (c_i' * y_cal))/round(bs * nodes_num)  + e;
        b_i = B(:,1:round(bs * nodes_num));
        c_i =  C(:,1:round(bs * nodes_num));
        gy = (-b_i * (b_i' * y_cal) + c_i * (c_i' * x_cal))/round(bs * nodes_num) +  f;
        if rr==R
            dist(iter+1,1)=cost;
            gnorm(iter+1,1) = norm([gx; gy],'fro');
            dist_inner((iter-1)*R + rr + 1,1)=cost;
            gnorm_inner((iter-1)*R + rr + 1,1) = norm([gx; gy],'fro');
        else
            dist_inner((iter-1)*R + rr + 1,1)=cost;
            gnorm_inner((iter-1)*R + rr + 1,1) = norm([gx; gy],'fro');
        end
    end
    disp(iter)
%     toc;
%     time(iter+1) = time(iter) + toc;
%     x_cal = mean(x_large,2);% the mean weight of network
%     y_cal = mean(y,2);
%     cost = norm([x_cal, y_cal]);
%     dist(iter+1,1)=cost;
% 
%     a_i = A(:,1:round(bs * nodes_num));
%     c_i = C(:,1:round(bs * nodes_num));
%     gx = (a_i * (a_i' * x_cal) + c_i * (c_i' * y_cal))/round(bs * nodes_num)  + e;
%     b_i = B(:,1:round(bs * nodes_num));
%     c_i =  C(:,1:round(bs * nodes_num));
%     gy = (-b_i * (b_i' * y_cal) + c_i * (c_i' * x_cal))/round(bs * nodes_num) +  f;
% 
%     gnorm(iter+1,1) = norm([gx; gy],'fro');
end
disp(dist)
%disp(Oracle)


