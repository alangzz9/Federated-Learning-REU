%clc; clear; close all;
clc;
clear
close all
tic
rng('default')




file_name = 'synthetic';
prob = 'line_log';



% % Parameters
n =          10;   % problem dimention
nodes_num  = 10;    % number of agents in the network
epoch_num  = 1000;
fig = 1;

generate_graph(nodes_num, 0.5, n, fig);
graph = load('graph_10.mat');
PW = graph.weights;


n_1 = 6000;
d = 10;
r = 5;
cond = 1e5;
data = pl_data_generator(n_1, d, cond,r);




% % Algorithms
x_initial = randn(nodes_num*n,epoch_num);
x_initial(:,1) = 1*randn(nodes_num*n,1);
alpha_initial = randn(nodes_num*1,epoch_num);
alpha_initial(:,1) = 1*randn(nodes_num,1);


 
iter_num = 10000;
batch_size = round(n_1/nodes_num);
%Pt = 0.1;
Pt=sqrt(batch_size)/(batch_size + sqrt(batch_size));
% stepsize_x=0.001;
% stepsize_y=0.001;
stepsize_x=0.01;
stepsize_y=0.01;
minibatch_D=round(sqrt(batch_size));
minibatch_C=round(sqrt(batch_size));
minibatch_local = round(sqrt(batch_size));
rho = sqrt(0.5/batch_size);
R = round(sqrt(batch_size));

if fig == 1
    filename = append('random_result_',file_name,'_',num2str(Pt),'_.mat');
else
    filename = append('result_',file_name,'_',num2str(Pt),'_.mat');
end

time = 0;
if time == 1
    filename = append('time_result_',file_name,'_',num2str(Pt),'_.mat');
    
end

iter_num = 5000;
stepsize_x=0.01;
stepsize_y=0.01;
disp('C_raw start')
% iter_num = 100;
[Oracle_C_raw, dist_C_raw, gnorm_C_raw, time_C_raw] = CMiniMax_for_synthetic(stepsize_x, stepsize_y, PW, data.w_init, data.z_init, iter_num, n,nodes_num,batch_size, minibatch_D,R, Pt, data.A, data.B, data.C, data.e, data.f);
save(filename, "Oracle_C_raw","dist_C_raw",'gnorm_C_raw',"time_C_raw")

iter_num = 5000;
stepsize_x=0.01;
stepsize_y=0.01;
disp('B_raw start')
% iter_num = 100;
[Oracle_B_raw, dist_B_raw, gnorm_B_raw, time_B_raw] = BMiniMax_for_synthetic(stepsize_x, stepsize_y, PW, data.w_init, data.z_init, iter_num, n,nodes_num,batch_size, minibatch_D,data.A, data.B, data.C, data.e, data.f);
save(filename, "Oracle_B_raw","dist_B_raw",'gnorm_B_raw',"time_B_raw",'-append')

iter_num = 1000;
disp('D start')
% iter_num = 100;
[Oracle_D, dist_D, gnorm_D, time_D, dist_D_i, gnorm_D_i] = DMiniMax_new_for_synthetic(stepsize_x, stepsize_y, PW, data.w_init, data.z_init, iter_num, n,nodes_num,batch_size, minibatch_D,rho,R, data.A, data.B, data.C, data.e, data.f);
save(filename, "Oracle_D","dist_D",'gnorm_D',"time_D",'dist_D_i','gnorm_D_i','-append')
            
disp('C start')
% iter_num = 100;
[Oracle_C, dist_C, gnorm_C, time_C, dist_C_i, gnorm_C_i] = CMiniMax_new_for_synthetic(stepsize_x, stepsize_y, PW, data.w_init, data.z_init, iter_num, n,nodes_num,batch_size, minibatch_C,R, Pt, data.A, data.B, data.C, data.e, data.f);
save(filename, "Oracle_C","dist_C",'gnorm_C',"time_C",'dist_C_i','gnorm_C_i','-append')
% 
% 
% 
% PW_1 = zeros(size(PW))+0.1;
% disp('D start_local')
% % iter_num = 100;
% [Oracle_D_local, dist_D_local, gnorm_D_local, time_D_local] = DMiniMax_new_for_synthetic(stepsize_x, stepsize_y, PW_1, data.w_init, data.z_init, iter_num, n,nodes_num,batch_size, minibatch_D,rho,R, data.A, data.B, data.C, data.e, data.f);
% save(filename, "Oracle_D_local","dist_D_local",'gnorm_D_local',"time_D_local",'-append')
%             
% disp('C start_local')
% % iter_num = 100;
% [Oracle_C_local, dist_C_local, gnorm_C_local,time_C_local] = CMiniMax_new_for_synthetic(stepsize_x, stepsize_y, PW_1, data.w_init, data.z_init, iter_num, n,nodes_num,batch_size, minibatch_C,R, Pt, data.A, data.B, data.C, data.e, data.f);
% save(filename, "Oracle_C_local","dist_C_local",'gnorm_C_local',"time_C_local",'-append')
