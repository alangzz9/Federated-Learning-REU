%clc; clear; close all;
clc;
clear
close all
tic
rng('default')
file_name = 'a9a';
prob = 'line_log';

% % --- logistic regression % % % 
%gc = @(x,lambda,alpha,v,y,bs, M) 1/(bs*M) * ((-y*v) / (1+exp(x'*v)) -(exp(x'*v)* v* (-1 + y))/(1 + exp(x'*v)) )  + 1/(bs*M) * 2*lambda*x ./ (1+x.^2).^2; % gradient
%fc = @(x,lambda,alpha,v,y,bs, M) 1/(bs*M) * (-y * log(1 / (1+exp(-x'*v))) - (1-y) * log(1 - 1 / (1+exp(-x'*v))) )   + 1/(bs*M) * lambda * sum(x.^2 ./ (1+x.^2)); % objective

% % % --- linear regression % % % 
% gc = @(x,lambda,alpha,v,y,bs, M) 1/(bs*M) *  -(v * (-x' *v + y))/(1 + 1/2 * (-x'*v + y)^2); % gradient
% fc = @(x,lambda,alpha,v,y,bs, M) 1/(bs*M) *  log((y - x'*v)^2/2 + 1); % objective
fc_1 = @(x,feature,ab1,ab0,alpha,p)  (((1-p)*(x'*[feature;ab1]).^2-2*(1+alpha)*(1-p)*x'*[feature;ab0])-p*(1-p)*alpha^2) + 0.001 * sum(x.^2 ./ (1+x.^2));
fc_0 = @(x,feature,ab1,ab0,alpha,p)  (p*(x'*[feature;ab1]).^2+ 2*(1+alpha)*p*x'*[feature;ab0]-p*(1-p)*alpha^2) + 0.001 * sum(x.^2 ./ (1+x.^2));

gc_v_1 = @(x,feature,ab1,ab0,alpha,p) 2*(1-p)*[feature;ab1]'*[feature;ab1]*x - 2*(1+alpha)*(1-p)*[feature;ab0]+2*0.001*x ./ (1+x.^2).^2;
gc_v_0 = @(x,feature,ab1,ab0,alpha,p) 2*p*([feature;ab1])'*[feature;ab1]*x+2*(1+alpha)*p*[feature;ab0]+2*0.001*x ./ (1+x.^2).^2;

gc_alpha_1 = @(x,feature,ab0,alpha,p) -2*(1-p)*x'*[feature;ab0] - 2*p*(1-p)*alpha;
gc_alpha_0 = @(x,feature,ab0,alpha,p) 2*p*x'*[feature;ab0]- 2*p*(1-p)*alpha;


% % Parameters
n          = 123;   % problem dimention
%batch_size = 3256;  % batch size
%minibatch  = 5;%round(sqrt(batch_size));%round(sqrt(n));
%epoch_length = round(batch_size/minibatch);%round(sqrt(n));%batch_size / minibatch;
nodes_num  = 10;    % number of agents in the network
%K = batch_size * nodes_num; % number of data points
repeat_num = 1;     % number of trials
epoch_num  = 1000;    % number of iterations per trial
radius     = 0.5;

function_lambda = 0.001;
function_aalpha = 1;

generate_graph(nodes_num, 0.5, n, 0);

% load data; split features and labels
load(sprintf('./data/%s.mat', file_name))
features = full(features);
labels = labels';
labels = cast(labels,'double');
labels(labels==0) = -1;


for idx = 1: size(labels, 1)
    features(idx, :) =  features(idx, :)./(norm(features(idx,:))+eps);
end

%%%% split the data
split_size=0.2;

index1 = find(labels==1);
index0 = find(labels==-1);

less= min(length(index1),length(index0));
label1 = index1(randperm(numel(index1),round(split_size/2*less)));
label0 = index0(randperm(numel(index0),round(split_size/2*less)));

x_test = features([label1,label0],:);
y_test = labels([label1,label0],:);
rand_index = randperm(size(y_test,1));
x_test = x_test(rand_index,:)';
y_test = y_test(rand_index,:);

x_train = features;
x_train([label1,label0],:)=[];
y_train = labels;
y_train([label1,label0],:)=[];


batch_size = floor(size(y_train,1)/nodes_num)
K = batch_size * nodes_num;


rand_index = randperm(size(y_train,1));
x_train = x_train(rand_index, :);
y_train = y_train(rand_index,:);
x_train = x_train(1:K,:)';
y_train = y_train(1:K,:);


% rand_index = randperm(size(labels, 1));
% features = features(rand_index, :);
% labels = labels(rand_index, :);
% features = features(1:K, :)';
% labels = labels(1:K, :);
momentum_coeff = 0.9;


stepsize_x=0.001;
stepsize_y=0.001;

minibatch_D=round(sqrt(batch_size));
minibatch_C=round(sqrt(batch_size))
% minibatch_D=64;
minibatch_B = 64;
minibatch_local = 64;
epoch_length_D = round(batch_size/minibatch_D);
epoch_length_B = round(batch_size/minibatch_B);
epoch_length_C = round(batch_size/minibatch_C);




graph = load('graph_10.mat');
Adj = graph.Adj;
PW = graph.weights;
A = graph.edges;


rho_=[1,0.1,0.01,0.001,0.0001];

% % Algorithms
    node_num=10;
    
    x_initial = zeros(nodes_num*n,epoch_num);
    x_initial(:,1) = 1*randn(nodes_num*n,1);
    alpha_initial = zeros(nodes_num*1,epoch_num);
    alpha_initial(:,1) = 1*randn(nodes_num,1);
    nodes_num=1;
    batch_size_ = floor(size(y_train,1)/nodes_num)*nodes_num;
    epoch_length_ = round(batch_size/minibatch_local);
    x_initial_ = zeros(n,epoch_num);
    x_initial_(:,1) = 1*rand(n,1);
    alpha_initial_ = zeros(1,epoch_num);
    alpha_initial_(:,1) = 1*randn(1,1);
    
%   lr = [1,0.1,0.01,0.001,0.0001];
  lr = [0.9];
  repeat_num= length(lr);
    %rho_=[0.1,0.01,0.001,0.0001];
    
%     momentum = 0.01;%rho_(repeat_index);
    
    rho = sqrt(0.5/batch_size);
    
    
    spectral_gap = 0.01;
    epsilon = 0.01;
    
for repeat_index = 1 : repeat_num
 
    for yy = 1:repeat_num
           
    stepsize_x = lr(repeat_index);
    stepsize_y =lr(yy);
    
       for gx=1:repeat_num
%            gamma_x = lr(gx);
           gamma_x = spectral_gap^2;
           for gy=1:repeat_num
           
            nodes_num=10;
%             gamma_y = lr(gy);
            gamma_y =spectral_gap^2;
            [Opt_grad(:,repeat_index), Opt_concensus(:,repeat_index), Obj(:,repeat_index), Oracle(:,repeat_index), AUCtest(:,repeat_index), acc(:,repeat_index), AUCtrain(:,repeat_index)] = DMiniMax(stepsize_x, stepsize_y, PW, x_initial, alpha_initial, round(epoch_num * epoch_length_D), A, n,nodes_num,gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0,fc_1,fc_0,function_lambda,function_aalpha, x_train,y_train, batch_size, minibatch_D,x_test,y_test,rho,gamma_x,gamma_y);
            our_acc(:,(repeat_index-1)*repeat_num*repeat_num*repeat_num+(yy-1)*repeat_num*repeat_num+(gx-1)*repeat_num+gy)=acc(:,repeat_index);
            our_AUCtest(:,(repeat_index-1)*repeat_num+yy)=AUCtest(:,repeat_index);

           end
       end
       beta_x = epsilon * min(1, 10 * epsilon);
       beta_y =  epsilon * min(1, 10 * epsilon);
        stepsize_x = spectral_gap^2* min(1, 10 * epsilon);
        stepsize_y = spectral_gap^2* min(1, 10 * epsilon);
       [Opt_grad_B(:,repeat_index), Opt_concensus_B(:,repeat_index), Obj_B(:,repeat_index), Oracle_B(:,repeat_index), AUCtest_B(:,repeat_index), acc_B(:,repeat_index), AUCtrain_B(:,repeat_index)] = BMiniMax(stepsize_x, stepsize_y, PW, x_initial, alpha_initial, round(epoch_num * epoch_length_B), A, n,nodes_num,gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0,fc_1,fc_0,function_lambda,function_aalpha, x_train,y_train, batch_size, minibatch_B,x_test,y_test,beta_x,beta_y);
        MD_acc(:,(repeat_index-1)*repeat_num+yy)=acc_B(:,repeat_index);
        MD_AUCtest(:,(repeat_index-1)*repeat_num+yy)=AUCtest_B(:,repeat_index);
        
        
%         stepsize_x = spectral_gap^2*0.05;
%         stepsize_y = spectral_gap^2*0.05;
        stepsize_x = spectral_gap^2*0.5;
        stepsize_y = spectral_gap^2*0.5;
       [Opt_grad_C(:,repeat_index), Opt_concensus_C(:,repeat_index), Obj_C(:,repeat_index), Oracle_C(:,repeat_index), AUCtest_C(:,repeat_index), acc_C(:,repeat_index), AUCtrain_C(:,repeat_index)] = CMiniMax(stepsize_x, stepsize_y, PW, x_initial, alpha_initial, round(epoch_num * epoch_length_C), A, n,nodes_num,gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0,fc_1,fc_0,function_lambda,function_aalpha, x_train,y_train, batch_size, minibatch_C,x_test,y_test);
        CD_acc(:,(repeat_index-1)*repeat_num+yy)=acc_C(:,repeat_index);
        CD_AUCtest(:,(repeat_index-1)*repeat_num+yy)=AUCtest_C(:,repeat_index);

        stepsize_x = spectral_gap^2*0.5;
        stepsize_y = spectral_gap^2*0.5;
       [Opt_grad_I(:,repeat_index), Opt_concensus_I(:,repeat_index), Obj_I(:,repeat_index), Oracle_I(:,repeat_index), AUCtest_I(:,repeat_index), acc_I(:,repeat_index), AUCtrain_I(:,repeat_index)] = GT_SRVRI(stepsize_x, stepsize_y, PW, x_initial, alpha_initial, round(epoch_num * epoch_length_C), A, n,nodes_num,gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0,fc_1,fc_0,function_lambda,function_aalpha, x_train,y_train, batch_size, minibatch_C,x_test,y_test);
        I_acc(:,(repeat_index-1)*repeat_num+yy)=acc_I(:,repeat_index);
        I_AUCtest(:,(repeat_index-1)*repeat_num+yy)=AUCtest_I(:,repeat_index);
       end
end

save result_line.mat


% load result
figure;
linewidth=2;
fontsize=14;
plot(our_AUCtest, 'r','linestyle', '-','linewidth',linewidth); hold on
plot(MD_AUCtest, 'b','linestyle', '-','linewidth',linewidth);hold on
plot(CD_AUCtest, 'm', 'linestyle', '-','linewidth',linewidth);
plot(I_AUCtest, 'c', 'linestyle', '-','linewidth',linewidth);

le = legend('Ours', 'DM-HSGD', 'GT-SRVR', 'GT-SRVRI', 'Location', 'southeast');
xl = xlabel('#Iterations','FontSize',fontsize);
yl = ylabel('AUC','FontSize',fontsize);
set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
set(get(gca,'YLabel'),'FontSize',fontsize);


figure;
linewidth=2;
fontsize=14;
plot(Oracle(2:end), our_AUCtest, 'r','linestyle', '-','linewidth',linewidth); hold on
plot(Oracle_C(2:end), CD_AUCtest, 'm', 'linestyle', '-','linewidth',linewidth);
plot(Oracle_I(2:end), I_AUCtest, 'c', 'linestyle', '-','linewidth',linewidth);

le = legend('Ours', 'GT-SRVR', 'GT-SRVRI', 'Location', 'southeast');
xl = xlabel('#Gradient evaluation','FontSize',fontsize);
yl = ylabel('AUC','FontSize',fontsize);
set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
set(get(gca,'YLabel'),'FontSize',fontsize);

% figue
% plot(acc, 'r'); hold on
% plot(acc_B, 'b');hold on
% plot(acc_C, 'm')
% legend('our', 'storm', 'spider')

% plot(AUCtrain, 'r'); hold on
% plot(AUCtrain_B, 'b');hold on
% plot(AUCtrain_C, 'm')
% legend('our', 'storm', 'spider')
% %==========================

% linewidth = 3;
% fontsize = 18;
% x_axis = (0:size(mean(Opt_grad,2))-1)./2;
% x_axis_scale_B = (0:size(mean(Opt_grad_B,2))-1)./epoch_length_B;
% x_axis_scale_D = (0:size(mean(Opt_grad,2))-1)./epoch_length_D;
% %x_axis_scale_ = (0:size(mean(opt_grad_local,2))-1)./epoch_length_;
% % figure
% % semilogy(x_axis_scale, mean(Obj,2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % xlim([0,epoch_num]);
% 
% figure
% %semilogy(x_axis_scale_D, our_acc,'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% %semilogy(x_axis_scale_B, MD_acc(:,1),'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% semilogy(x_axis_scale_B, MD_acc(:,9:15),'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('1','2,','3','4','5','6','7','8');
% 
% figure
% %semilogy(x_axis_scale_D, our_acc,'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% %semilogy(x_axis_scale_B, MD_acc(:,1),'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% semilogy(x_axis_scale_B, MD_acc(:,3:7),'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('3','4','5','6','7');
% 
% figure
% %semilogy(x_axis_scale_D, our_acc,'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(x_axis_scale_D, our_acc(:,203),'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% semilogy(x_axis_scale_D, our_acc(:,128),'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% 
% le = legend('6','7','8','9','10','11','12','13','14','15');
% 
% figure
% semilogy(x_axis_scale_D, our_acc,'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% le=legend('lrx=0.1 lry=0.1','lrx=0.1 lry=0.01','lrx=0.1 lry=0.001','lrx=0.1 lry=0.0001',...
%     'lrx=0.01 lry=0.1','lrx=0.01 lry=0.01','lrx=0.01 lry=0.001','lrx=0.01 lry=0.0001',...
%     'lrx=0.001 lry=0.1','lrx=0.001 lry=0.01','lrx=0.001 lry=0.001','lrx=0.001 lry=0.0001',...
%     'lrx=0.0001 lry=0.1','lrx=0.0001 lry=0.01','lrx=0.0001 lry=0.001','lrx=0.0001 lry=0.0001');
% 
% figure
% semilogy(x_axis_scale_B, MD_acc(:,4:16),'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% le=legend(...%'lrx=0.1 lry=0.1','lrx=0.1 lry=0.01','lrx=0.1 lry=0.001',
%             'lrx=0.1 lry=0.0001',...
%     'lrx=0.01 lry=0.1','lrx=0.01 lry=0.01','lrx=0.01 lry=0.001','lrx=0.01 lry=0.0001',...
%     'lrx=0.001 lry=0.1','lrx=0.001 lry=0.01','lrx=0.001 lry=0.001','lrx=0.001 lry=0.0001',...
%     'lrx=0.0001 lry=0.1','lrx=0.0001 lry=0.01','lrx=0.0001 lry=0.001','lrx=0.0001 lry=0.0001');
% 
% figure
% semilogy(x_axis_scale_D, our_acc(:,128),'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(x_axis_scale_B, MD_acc(:,8),'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('our method','MD-HSGD');
% xl = xlabel('#Epochs','FontSize',fontsize);
% yl = ylabel('Accuracy','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho%f_auc_epoch_our_method.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y,rho));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'acc_epoch_our_method_vs_MD-HSGD_best'
% 
% figure
% semilogy(x_axis_scale_D, our_AUCtest(:,4),'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(x_axis_scale_B, MD_AUCtest(:,4),'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('our method','MD-HSGD');
% xl = xlabel('#Epochs','FontSize',fontsize);
% yl = ylabel('AUC','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho%f_auc_epoch_our_method.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y,rho));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'auc_epoch_our_method_vs_MD-HSGD_best'
% 
% 
% figure
% semilogy(mean(Oracle(1:end-1, :),2), our_AUCtest(:,4),'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(mean(Oracle_B(1:end-1, :),2), MD_AUCtest(:,4),'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('our method','MD-HSGD');
% xl = xlabel('#Gradient evaluation','FontSize',fontsize);
% yl = ylabel('AUC','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho_auc_epoch_vs.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'auc_eval_our_method_vs_MD-HSGD_best'
% 
% figure
% semilogy(mean(Oracle(1:end-1, :),2), our_acc(:,4),'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(mean(Oracle_B(1:end-1, :),2), MD_acc(:,4),'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('our method','MD-HSGD');
% xl = xlabel('#Gradient evaluation','FontSize',fontsize);
% yl = ylabel('Accuracy','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho_acc_epoch_vs.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'acc_eval_our_method_vs_MD-HSGD_best'
% 
% 
% 
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% figure
% semilogy(x_axis_scale_D, AUCtest,'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(x_axis_scale_B, AUCtest_B,'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('our method','MD-HSGD');
% xl = xlabel('#Epochs','FontSize',fontsize);
% yl = ylabel('AUC','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho%f_auc_epoch_our_method.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y,rho));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'auc_epoch_our_method_vs_MD-HSGD_best'
% 
% 
% 
% 
% figure
% semilogy(x_axis_scale_D, acc,'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(x_axis_scale_B, acc_B,'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('our method','MD-HSGD');
% xl = xlabel('#Epochs','FontSize',fontsize);
% yl = ylabel('AUC','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho%f_auc_epoch_our_method.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y,rho));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'auc_epoch_our_method_vs_MD-HSGD'
% 
% figure
% semilogy(x_axis_scale_D, acc,'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(x_axis_scale_B, acc_B,'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('our rho=0.1','our0.01','our0.001','our0.0001',...
%     'MD-HSGD0.1','MD-HSGD0.01','MD-HSGD0.001','MD-HSGD0.0001');
% xl = xlabel('#Epochs','FontSize',fontsize);
% yl = ylabel('AUC','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho%f_auc_epoch_vs.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y,rho));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'acc_epoch_our_method_vs_MD-HSGD'
% 
% 
% figure
% semilogy(mean(Oracle(1:end-1, :),2), AUCtest,'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(mean(Oracle(1:end-1, :),2), AUCtest_B,'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('our rho=0.1','our0.01','our0.001','our0.0001',...
%     'MD-HSGD0.1','MD-HSGD0.01','MD-HSGD0.001','MD-HSGD0.0001');
% xl = xlabel('#Gradient evaluation','FontSize',fontsize);
% yl = ylabel('AUC','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho_auc_epoch_vs.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'auc_eval_our_method_vs_MD-HSGD'
% 
% figure
% semilogy(mean(Oracle(1:end-1, :),2), acc,'linestyle', '-','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(mean(Oracle(1:end-1, :),2), acc_B,'linestyle', '-.','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% le = legend('our0.1','our0.01','our0.001','our0.0001',...
%     'MD-HSGD0.1','MD-HSGD0.01','MD-HSGD0.001','MD-HSGD0.0001');
% xl = xlabel('#Gradient evaluation','FontSize',fontsize);
% yl = ylabel('Accuracy','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho_acc_epoch_vs.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'acc_eval_our_method_vs_MD-HSGD'
% 
% 
% 
% for i=1:length(rho_)
%     rho=rho_(i);
% figure
% semilogy(x_axis_scale_D, AUCtest(:,i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(x_axis_scale_B, AUCtest_B(:,i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% semilogy(x_axis_scale_, AUC_local(:,i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_)/10):length(x_axis_scale_));hold on;
% le = legend( 'Our method','DM-HSGD','local');
% xl = xlabel('#Epochs','FontSize',fontsize);
% yl = ylabel('Accuracy','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho%f_accuracy_epoch.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y,rho));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'accuracy_epoch'    
%     
% figure
% semilogy(x_axis_scale_D, acc(:,i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(x_axis_scale_B, acc_B(:,i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% semilogy(x_axis_scale_, acc_local(:,i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_)/10):length(x_axis_scale_));hold on;
% le = legend( 'Our method','DM-HSGD','local');
% xl = xlabel('#Epochs','FontSize',fontsize);
% yl = ylabel('Accuracy','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho%f_accuracy_epoch.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y,rho));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'accuracy_epoch'
% 
% %#evaluation vs auc/accuracy
% 
% figure
% semilogy(Oracle(1:end-1, i), AUCtest(1:end, i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(Oracle_B(1:end-1, i), AUCtest_B(1:end, i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% semilogy(Oracle_local(1:end-1, i), AUC_local(1:end, i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_)/10):length(x_axis_scale_));hold on;
% le = legend( 'Our method', 'DM-HSGD','local');
% xl = xlabel('#Gradiet evaluations','FontSize',fontsize);
% yl = ylabel('AUC','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lrx%f_lry%f_rho%f_auc_comm.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y,rho));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'auc_eval'
% 
% figure
% semilogy(mean(Oracle(1:end-1, i),2), acc(1:end, i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_D)/10):length(x_axis_scale_D));hold on;
% semilogy(mean(Oracle_B(1:end-1, i),2), acc_B(1:end, i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_B)/10):length(x_axis_scale_B));hold on;
% semilogy(mean(Oracle_local(1:end-1, i),2), acc_local(1:end, i),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale_)/10):length(x_axis_scale_));hold on;
% le = legend( 'Our method', 'DM-HSGD','local');
% xl = xlabel('#Gradiet evaluations','FontSize',fontsize);
% yl = ylabel('Accuracy','FontSize',fontsize);
% set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
% set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
% set(get(gca,'YLabel'),'FontSize',fontsize);
% savefig(sprintf('figure_%s_%s_bs%d_%d_%d_ep%d_lr%f_lry%f_rho%f_acc_comm.fig',file_name, prob, minibatch_D,minibatch_B,minibatch_local, epoch_num, stepsize_x,stepsize_y,rho));
% set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters 'accuracy_eval'
% end
% % figure
% % semilogy(x_axis_scale, acc,'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % xlim([0,epoch_num]);
% % semilogy(x_axis_scale, mean(Opt_GNSD,2),'linestyle', '--','linewidth',linewidth,   'Marker', 'x', 'MarkerIndices',1:round(length(x_axis_scale)/9):length(x_axis_scale));hold on;
% % semilogy(x_axis_scale, mean(Opt_DSGDM,2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale)/11):length(x_axis_scale));hold on;
% % semilogy(x_axis_scale, mean(Opt_DGET,2),'linestyle', '-','linewidth',linewidth,  'Marker', 's', 'MarkerIndices',1:round(length(x_axis_scale)/8):length(x_axis_scale));hold on;
% % semilogy(x_axis_scale, mean(Opt_ADGT,2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'd', 'MarkerIndices',1:round(length(x_axis_scale)/7):length(x_axis_scale));hold on;
% % 
% % xlim([0,epoch_num-2]);
% % le = legend('PSGD', 'GNSD',  'DSGDM', 'DGET', 'ADGT');
% % xl = xlabel('Epoch','FontSize',fontsize);
% % yl = ylabel('Optimality Gap','FontSize',fontsize);
% % grid on;
% 
% % figure
% % semilogy(mean(Oracle_EDSGD(1:end-1, :),2), mean(Obj_EDSGD(1:end, :),2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_PSGD(1:end-1, :),2), mean(Obj_PSGD(1:end, :),2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_DSGDM(1:end-1, :),2), mean(Obj_DSGDM(1:end, :),2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale)/11):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_HSGD(1:end-1, :),2), mean(Obj_HSGD(1:end, :),2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/12):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_DGET(1:end-2, :),2), mean(Obj_DGET(1:end, :),2),'linestyle', '-','linewidth',linewidth,  'Marker', 's', 'MarkerIndices',1:round(length(x_axis_scale)/8):length(x_axis_scale));hold on;
% % le = legend( 'EDSGD','PSGD', 'DSGDM', 'HSGD', 'DGET');
% % xl = xlabel('#Gradiet evaluations','FontSize',fontsize);
% % yl = ylabel('Objective Value','FontSize',fontsize);
% % savefig(sprintf('figure_%s_%s_bs%d_ep%d_%f_opt_comm.fig',file_name, prob, batch_size, epoch_num, stepsize));
% 
% % 
% % figure
% % semilogy(mean(Oracle_EDSGD(1:end-1, :),2), mean(Opt_grad_EDSGD(1:end, :),2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_PSGD(1:end-1, :),2), mean(Opt_grad_PSGD(1:end, :),2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_DSGDM(1:end-1, :),2), mean(Opt_grad_DSGDM(1:end, :),2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale)/11):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_HSGD(1:end-1, :),2), mean(Opt_grad_HSGD(1:end, :),2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/12):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_DGET(1:end-2, :),2), mean(Opt_grad_DGET(1:end, :),2),'linestyle', '-','linewidth',linewidth,  'Marker', 's', 'MarkerIndices',1:round(length(x_axis_scale)/8):length(x_axis_scale));hold on;
% % le = legend( 'EDSGD','PSGD', 'DSGDM', 'HSGD', 'DGET');
% % xl = xlabel('#Gradiet evaluations','FontSize',fontsize);
% % yl = ylabel('Grad','FontSize',fontsize);
% 
% % 
% % figure
% % 
% % semilogy(mean(Oracle_EDSGD(1:end-1, :),2), mean(Opt_concensus_EDSGD(1:end, :),2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_PSGD(1:end-1, :),2), mean(Opt_concensus_PSGD(1:end, :),2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % % semilogy(mean(Oracle_GNSD(1:end-1, :),2), mean(Obj_GNSD(2:end, :),2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/6):length(x_axis_scale));hold on;
% % %semilogy(mean(Oracle_DSGTM(1:end-1, :),2), mean(Opt_concensus_DSGTM(1:end, :),2),'linestyle', '--','linewidth',linewidth,  'Marker', 'x', 'MarkerIndices',1:round(length(x_axis_scale)/9):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_DSGDM(1:end-1, :),2), mean(Opt_concensus_DSGDM(1:end, :),2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale)/11):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_HSGD(1:end-1, :),2), mean(Opt_concensus_HSGD(1:end, :),2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/12):length(x_axis_scale));hold on;
% % semilogy(mean(Oracle_DGET(1:end-2, :),2), mean(Opt_concensus_DGET(1:end, :),2),'linestyle', '-','linewidth',linewidth,  'Marker', 's', 'MarkerIndices',1:round(length(x_axis_scale)/8):length(x_axis_scale));hold on;
% % %semilogy(mean(Oracle_ADGT(1:end-1, :),2), mean(Opt_concensus_ADGT(1:end, :),2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'd', 'MarkerIndices',1:round(length(x_axis_scale)/7):length(x_axis_scale));hold on;
% % 
% % % xlim([0,epoch_num-2]);
% % le = legend( 'EDSGD','PSGD', 'DSGDM', 'HSGD', 'DGET');
% % xl = xlabel('#Gradiet evaluations','FontSize',fontsize);
% % yl = ylabel('Concensus','FontSize',fontsize);
% % 
% 
% %===============================
% % figure
% % semilogy(x_axis_scale, mean(Opt_EDSGD,2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % semilogy(x_axis_scale, mean(Opt_GNSD,2),'linestyle', '--','linewidth',linewidth,   'Marker', 'x', 'MarkerIndices',1:round(length(x_axis_scale)/9):length(x_axis_scale));hold on;
% % semilogy(x_axis_scale, mean(Opt_DSGDM,2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(x_axis_scale)/11):length(x_axis_scale));hold on;
% % semilogy(x_axis_scale, mean(Opt_DGET,2),'linestyle', '-','linewidth',linewidth,  'Marker', 's', 'MarkerIndices',1:round(length(x_axis_scale)/8):length(x_axis_scale));hold on;
% % semilogy(x_axis_scale, mean(Opt_ADGT,2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'd', 'MarkerIndices',1:round(length(x_axis_scale)/7):length(x_axis_scale));hold on;
% % 
% % xlim([0,epoch_num-2]);
% % le = legend('PSGD', 'GNSD',  'DSGDM', 'DGET', 'ADGT');
% % xl = xlabel('Epoch','FontSize',fontsize);
% % yl = ylabel('Optimality Gap','FontSize',fontsize);
% % grid on;
% % savefig(sprintf('figure_%s_%s_bs%d_ep%d_%f_opt.fig',file_name, prob, batch_size, epoch_num, stepsize));
% % 
% % 
% 
% % grid on;
% % savefig(sprintf('figure_%s_%s_bs%d_ep%d_%f_loss_256.fig',file_name, prob, batch_size, epoch_num, stepsize));
% % 
% % num_iters = size(Opt_DSGDM, 1);
% % itx = 1:num_iters;
% % itx_momentum = itx * 2;
% % itx_m = itx_momentum(1:num_iters/2);
% % itx_adgt = itx * 3;
% % itx_adgt = itx_adgt(1:ceil(num_iters/3));
% % 
% % figure;
% % semilogy(itx, mean(Opt_PSGD,2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % semilogy(itx_m, mean(Opt_GNSD(1:num_iters/2,:),2),'linestyle', '--','linewidth',linewidth,  'Marker', 'x', 'MarkerIndices',1:round(length(itx_m)/9):length(itx_m));hold on;
% % semilogy(itx_m, mean(Opt_DSGDM(1:num_iters/2,:),2),'linestyle', '-.','linewidth',linewidth, 'Marker', 'o', 'MarkerIndices',1:round(length(itx_m)/11):length(itx_m));hold on;
% % semilogy(itx_m, mean(Opt_DGET(1:num_iters/2,:),2),'linestyle', '-','linewidth',linewidth,  'Marker', 's', 'MarkerIndices',1:round(length(itx_m)/8):length(itx_m));hold on;
% % semilogy(itx_adgt, mean(Opt_ADGT(1:ceil(num_iters/3),:),2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'd', 'MarkerIndices',1:round(length(itx_adgt)/7):length(itx_adgt));hold on;
% % le = legend('PSGD', 'GNSD', 'DSGDM',  'DGET', 'ADGT');
% % xl = xlabel('Communication Rounds','FontSize',fontsize);
% % yl = ylabel('Optimality Gap','FontSize',fontsize);
% % grid on;
% % savefig(sprintf('figure_%s_%s_bs%d_ep%d_%f_opt_comm.fig',file_name, prob, batch_size, epoch_num, stepsize));
% % 
% % 
% % figure;
% % semilogy(itx, mean(Obj_PSGD,2),'linestyle', ':','linewidth',linewidth,  'Marker', '+', 'MarkerIndices',1:round(length(x_axis_scale)/10):length(x_axis_scale));hold on;
% % semilogy(itx_m, mean(Obj_GNSD(1:num_iters/2,:),2),'linestyle', '--','linewidth',linewidth,  'Marker', 'x', 'MarkerIndices',1:round(length(itx_m)/9):length(itx_m));hold on;
% % semilogy(itx_m, mean(Obj_DSGDM(1:num_iters/2,:),2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'o', 'MarkerIndices',1:round(length(itx_m)/11):length(itx_m));hold on;
% % semilogy(itx_m, mean(Obj_DGET(1:num_iters/2,:),2),'linestyle', '-','linewidth',linewidth,  'Marker', 's', 'MarkerIndices',1:round(length(itx_m)/8):length(itx_m));hold on;
% % semilogy(itx_adgt, mean(Obj_ADGT(1:ceil(num_iters/3),:),2),'linestyle', '-.','linewidth',linewidth,  'Marker', 'd', 'MarkerIndices',1:round(length(itx_adgt)/7):length(itx_adgt));hold on;
% % le = legend('PSGD', 'GNSD',  'DSGDM', 'DGET', 'ADGT');
% % xl = xlabel('Communication Rounds','FontSize',fontsize);
% % yl = ylabel('Objective Value','FontSize',fontsize);
% % grid on;
% % savefig(sprintf('figure_%s_%s_bs%d_ep%d_%f_loss_comm.fig',file_name, prob, batch_size, epoch_num, stepsize));



