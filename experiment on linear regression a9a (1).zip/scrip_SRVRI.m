%clc; clear; close all;
clc;
clear
close all
tic
rng('default')
file_name = 'a9a';
prob = 'line_log';

% % --- logistic regression % % % 
%gc = @(x,lambda,alpha,v,y,bs, M) 1/(bs*M) * ((-y*v) / (1+exp(x'*v)) -(exp(x'*v)* v* (-1 + y))/(1 + exp(x'*v)) )  + 1/(bs*M) * 2*lambda*x ./ (1+x.^2).^2; % gradient
%fc = @(x,lambda,alpha,v,y,bs, M) 1/(bs*M) * (-y * log(1 / (1+exp(-x'*v))) - (1-y) * log(1 - 1 / (1+exp(-x'*v))) )   + 1/(bs*M) * lambda * sum(x.^2 ./ (1+x.^2)); % objective

% % % --- linear regression % % % 
% gc = @(x,lambda,alpha,v,y,bs, M) 1/(bs*M) *  -(v * (-x' *v + y))/(1 + 1/2 * (-x'*v + y)^2); % gradient
% fc = @(x,lambda,alpha,v,y,bs, M) 1/(bs*M) *  log((y - x'*v)^2/2 + 1); % objective
fc_1 = @(x,feature,ab1,ab0,alpha,p)  (((1-p)*(x'*[feature;ab1]).^2-2*(1+alpha)*(1-p)*x'*[feature;ab0])-p*(1-p)*alpha^2) + 0.001 * sum(x.^2 ./ (1+x.^2));
fc_0 = @(x,feature,ab1,ab0,alpha,p)  (p*(x'*[feature;ab1]).^2+ 2*(1+alpha)*p*x'*[feature;ab0]-p*(1-p)*alpha^2) + 0.001 * sum(x.^2 ./ (1+x.^2));

gc_v_1 = @(x,feature,ab1,ab0,alpha,p) 2*(1-p)*[feature;ab1]'*[feature;ab1]*x - 2*(1+alpha)*(1-p)*[feature;ab0]+2*0.001*x ./ (1+x.^2).^2;
gc_v_0 = @(x,feature,ab1,ab0,alpha,p) 2*p*([feature;ab1])'*[feature;ab1]*x+2*(1+alpha)*p*[feature;ab0]+2*0.001*x ./ (1+x.^2).^2;

gc_alpha_1 = @(x,feature,ab0,alpha,p) -2*(1-p)*x'*[feature;ab0] - 2*p*(1-p)*alpha;
gc_alpha_0 = @(x,feature,ab0,alpha,p) 2*p*x'*[feature;ab0]- 2*p*(1-p)*alpha;


% % Parameters
n          = 123;   % problem dimention
%batch_size = 3256;  % batch size
%minibatch  = 5;%round(sqrt(batch_size));%round(sqrt(n));
%epoch_length = round(batch_size/minibatch);%round(sqrt(n));%batch_size / minibatch;
nodes_num  = 10;    % number of agents in the network
%K = batch_size * nodes_num; % number of data points
repeat_num = 1;     % number of trials
epoch_num  = 100;    % number of iterations per trial
radius     = 0.5;

function_lambda = 0.001;
function_aalpha = 1;

generate_graph(nodes_num, 0.5, n, 1);

% load data; split features and labels
load(sprintf('./data/%s.mat', file_name))
features = full(features);
labels = labels';
labels = cast(labels,'double');
labels(labels==0) = -1;


for idx = 1: size(labels, 1)
    features(idx, :) =  features(idx, :)./(norm(features(idx,:))+eps);
end

%%%% split the data
split_size=0.2;

index1 = find(labels==1);
index0 = find(labels==-1);

less= min(length(index1),length(index0));
label1 = index1(randperm(numel(index1),round(split_size/2*less)));
label0 = index0(randperm(numel(index0),round(split_size/2*less)));

x_test = features([label1,label0],:);
y_test = labels([label1,label0],:);
rand_index = randperm(size(y_test,1));
x_test = x_test(rand_index,:)';
y_test = y_test(rand_index,:);

x_train = features;
x_train([label1,label0],:)=[];
y_train = labels;
y_train([label1,label0],:)=[];


batch_size = floor(size(y_train,1)/nodes_num);
K = batch_size * nodes_num;


rand_index = randperm(size(y_train,1));
x_train = x_train(rand_index, :);
y_train = y_train(rand_index,:);
x_train = x_train(1:K,:)';
y_train = y_train(1:K,:);


% rand_index = randperm(size(labels, 1));
% features = features(rand_index, :);
% labels = labels(rand_index, :);
% features = features(1:K, :)';
% labels = labels(1:K, :);
momentum_coeff = 0.9;


stepsize_x=0.001;
stepsize_y=0.001;

minibatch_D=round(sqrt(batch_size));
minibatch_C=round(sqrt(batch_size));
% minibatch_D=64;
minibatch_B = 64;
minibatch_local = 64;
epoch_length_D = round(batch_size/minibatch_D);
epoch_length_B = round(batch_size/minibatch_B);
epoch_length_C = round(batch_size/minibatch_C);




graph = load('graph_10.mat');
Adj = graph.Adj;
PW = graph.weights;
A = graph.edges;


rho_=[1,0.1,0.01,0.001,0.0001];

% % Algorithms
    node_num=10;
    
    x_initial = zeros(nodes_num*n,epoch_num);
    x_initial(:,1) = 1*randn(nodes_num*n,1);
    alpha_initial = zeros(nodes_num*1,epoch_num);
    alpha_initial(:,1) = 1*randn(nodes_num,1);
    nodes_num=1;
    batch_size_ = floor(size(y_train,1)/nodes_num)*nodes_num;
    epoch_length_ = round(batch_size/minibatch_local);
    x_initial_ = zeros(n,epoch_num);
    x_initial_(:,1) = 1*rand(n,1);
    alpha_initial_ = zeros(1,epoch_num);
    alpha_initial_(:,1) = 1*randn(1,1);
    
  lr = [0.9, 0.7, 0.5, 0.3, 0.1];
%   lr = [0.9];
  repeat_num= length(lr);
    %rho_=[0.1,0.01,0.001,0.0001];
    
%     momentum = 0.01;%rho_(repeat_index);
    
    rho = sqrt(0.5/batch_size);
    
    
    spectral_gap = 0.5;
    epsilon = 0.01;
    
for repeat_index = 1 : repeat_num
 
%     for yy = 1:repeat_num
           

    gamma_x = spectral_gap^2;

    nodes_num=10;
    gamma_y =spectral_gap^2;



end

repeat_index = 1;
beta_x = epsilon * min(1, 10 * epsilon);
beta_y =  epsilon * min(1, 10 * epsilon);



stepsize_x = spectral_gap^2*0.01;
stepsize_y = spectral_gap^2*0.01;
[Opt_grad_C(:,repeat_index), Opt_concensus_C(:,repeat_index), Obj_C(:,repeat_index), Oracle_C(:,repeat_index), AUCtest_C(:,repeat_index), acc_C(:,repeat_index), AUCtrain_C(:,repeat_index)] = GT_SRVRI(stepsize_x, stepsize_y, PW, x_initial, alpha_initial, round(epoch_num * epoch_length_C), A, n,nodes_num,gc_v_1,gc_v_0,gc_alpha_1,gc_alpha_0,fc_1,fc_0,function_lambda,function_aalpha, x_train,y_train, batch_size, minibatch_C,x_test,y_test);
% CD_acc(:,(repeat_index-1)*repeat_num+yy)=acc_C(:,repeat_index);
% CD_AUCtest(:,(repeat_index-1)*repeat_num+yy)=AUCtest_C(:,repeat_index);

linewidth=2;
fontsize=14;
plot(AUCtest(:,1), 'linestyle', '-','linewidth',linewidth); hold on
plot(AUCtest(:,2), 'linestyle', '-','linewidth',linewidth); hold on
plot(AUCtest(:,3), 'linestyle', '-','linewidth',linewidth); hold on
plot(AUCtest(:,4), 'linestyle', '-','linewidth',linewidth); hold on
plot(AUCtest(:,5), 'linestyle', '-','linewidth',linewidth); hold on
plot(AUCtest_B(:,1), 'linestyle', '-','linewidth',linewidth); hold on
plot(AUCtest_C(:,1), 'linestyle', '-','linewidth',linewidth); hold on

le = legend('\eta=0.9', '\eta=0.7', '\eta=0.5','\eta=0.3','\eta=0.1', 'DM-HSGD', 'GT-SRVR');
xl = xlabel('#Iterations','FontSize',fontsize);
yl = ylabel('AUC','FontSize',fontsize);
set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
set(get(gca,'YLabel'),'FontSize',fontsize);


figure;
linewidth=2;
fontsize=14;
plot(Oracle(2:end, 1), AUCtest(:,1), 'linestyle', '-','linewidth',linewidth); hold on
plot(Oracle(2:end, 2), AUCtest(:,2), 'linestyle', '-','linewidth',linewidth); hold on
plot(Oracle(2:end, 3), AUCtest(:,3), 'linestyle', '-','linewidth',linewidth); hold on
plot(Oracle(2:end, 4), AUCtest(:,4), 'linestyle', '-','linewidth',linewidth); hold on
plot(Oracle(2:end, 5), AUCtest(:,5), 'linestyle', '-','linewidth',linewidth); hold on
plot(Oracle_C(2:end),AUCtest_C(:,1), 'linestyle', '-','linewidth',linewidth); hold on

le = legend('\eta=0.9', '\eta=0.7', '\eta=0.5','\eta=0.3','\eta=0.1','GT-SRVR');
xl = xlabel('#Gradient evaluation','FontSize',fontsize);
yl = ylabel('AUC','FontSize',fontsize);
set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
set(get(gca,'YLabel'),'FontSize',fontsize);

%===============================
% save result_random.mat
% load result
figure;
linewidth=2;
fontsize=14;
plot(AUCtest(:,1), 'r','linestyle', '-','linewidth',linewidth); hold on
plot(AUCtest_B(:,1), 'b','linestyle', '-','linewidth',linewidth);hold on
plot(AUCtest_C(:,1), 'm', 'linestyle', '-','linewidth',linewidth);

le = legend('Ours', 'DM-HSGD', 'GT-SRVR');
xl = xlabel('#Iterations','FontSize',fontsize);
yl = ylabel('AUC','FontSize',fontsize);
set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
set(get(gca,'YLabel'),'FontSize',fontsize);


figure;
linewidth=2;
fontsize=14;
plot(Oracle(2:end, 1), AUCtest(:,1), 'r','linestyle', '-','linewidth',linewidth); hold on
plot(Oracle_C(2:end), AUCtest_C(:,1), 'm', 'linestyle', '-','linewidth',linewidth);

le = legend('Ours', 'GT-SRVR');
xl = xlabel('#Gradient evaluation','FontSize',fontsize);
yl = ylabel('AUC','FontSize',fontsize);
set(gca,'FontSize',fontsize); % 设置文字大小，同时影响坐标轴标注、图例、标题等。
set(get(gca,'XLabel'),'FontSize',fontsize);%图上文字为8 point或小5号
set(get(gca,'YLabel'),'FontSize',fontsize);

% figue
% plot(acc, 'r'); hold on
% plot(acc_B, 'b');hold on
% plot(acc_C, 'm')
% legend('our', 'storm', 'spider')

% plot(AUCtrain, 'r'); hold on
% plot(AUCtrain_B, 'b');hold on
% plot(AUCtrain_C, 'm')
% legend('our', 'storm', 'spider')
% %==========================

